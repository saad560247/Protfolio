**Blogin web template**

Fully responsive blogin web template demo No bootstrap or plugin only html5,css and media query

[Live demo](https://siddique000.github.io/blogin-web-template/)
